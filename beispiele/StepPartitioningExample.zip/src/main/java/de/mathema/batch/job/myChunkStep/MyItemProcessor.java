package de.mathema.batch.job.myChunkStep;

import java.util.HashMap;

import de.mathema.batch.job.Hero;
import de.mathema.batch.util.Constants;
import jakarta.batch.api.chunk.ItemProcessor;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;

public class MyItemProcessor implements ItemProcessor {
    @Inject
    StepContext stepContext;
    int avengerCounter = 0;
    HashMap<Integer, Hero> collectedData = new HashMap<>();

    @Override
    public Object processItem(Object item) throws Exception {
        Hero hero = (Hero) item;
        if (hero.getTeam().equals(Constants.AVENGERS)) {
            avengerCounter++;
            collectedData.put(avengerCounter, hero);
        }
        stepContext.setPersistentUserData(collectedData);
        return item;
    }
}
