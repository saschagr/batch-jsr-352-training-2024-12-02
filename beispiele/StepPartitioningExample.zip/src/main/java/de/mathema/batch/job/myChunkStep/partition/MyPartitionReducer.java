package de.mathema.batch.job.myChunkStep.partition;

import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import de.mathema.batch.job.Hero;
import jakarta.batch.api.partition.PartitionReducer;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;


public class MyPartitionReducer implements PartitionReducer {

    @Inject
    StepContext stepContext;
    HashMap<Integer, Hero> analyzedData = new HashMap<>();

    @Override
    public void beginPartitionedStep() {
        System.out.println("PartitionReducer.beginPartitionedStep()");
    }

    @Override
    public void beforePartitionedStepCompletion() {
        System.out.println("PartitionReducer.beforePartitionedStepCompletion()");
        analyzedData = (HashMap<Integer, Hero>) stepContext.getPersistentUserData();
//        if (analyzedData.size() != 0) {
//            for(Map.Entry<Integer, Hero> entry : analyzedData.entrySet())   {
//                System.out.println("Key: " + entry.getKey() + ", Hero: " + entry.getValue().getHeroName() + ", PL: " + entry.getValue().getPowerLevel());
//            };
//        }
    }

    @Override
    public void rollbackPartitionedStep() {
        System.out.println("PartitionReducer.rollbackPartitionedStep()");
    }

    @Override
    public void afterPartitionedStepCompletion(PartitionStatus status) {
        analyzedData = (HashMap<Integer, Hero>) stepContext.getPersistentUserData();
        if (analyzedData != null) {
            List<Hero> filteredData = analyzedData.entrySet().stream()
                    .filter(entry -> Integer.valueOf(entry.getValue().getPowerLevel()) >= 8)
                    .map(entry -> entry.getValue())
                    .collect(Collectors.toList());

            System.out.println("------------------------------------------------------------------------");
            System.out.println("Filtered data");
            System.out.println("------------------------------------------------------------------------");
            filteredData.forEach(hero -> {
                if (hero != null) {
                    System.out.println(hero.getHeroName() + ", PL: " + hero.getPowerLevel());
                }
            });
        }
    }
}

