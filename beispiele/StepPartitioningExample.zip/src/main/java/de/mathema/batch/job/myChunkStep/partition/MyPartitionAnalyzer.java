package de.mathema.batch.job.myChunkStep.partition;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import de.mathema.batch.job.Hero;
import jakarta.batch.api.partition.PartitionAnalyzer;
import jakarta.batch.runtime.BatchStatus;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;

public class MyPartitionAnalyzer implements PartitionAnalyzer {
    HashMap<Integer, Hero> collection = new HashMap<>();

    @Inject
    StepContext stepContext;
    @Override
    public void analyzeCollectorData(Serializable data) throws Exception {
       collection = (HashMap<Integer, Hero>) data;
        if (collection.size() != 0) {
            System.out.println("PartitionAnalyzer.analyzeCollectorData()");
            for(Map.Entry<Integer, Hero> entry : collection.entrySet())   {
                System.out.println("Id: " + entry.getKey() + ", Hero: " + entry.getValue().getHeroName() + ", Power Level: " + entry.getValue().getPowerLevel());
            };
        }
        stepContext.setPersistentUserData(collection);
    }

    @Override
    public void analyzeStatus(BatchStatus batchStatus, String exitStatus) throws Exception {
        System.out.println(
                "PartitionAnalyzer.analyzeStatus() - batchStatus: " + batchStatus
                        + ", exitStatus: " + exitStatus);
    }
}
