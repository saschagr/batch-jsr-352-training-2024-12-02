package de.mathema.batch.job;

import java.io.Serializable;

public class Hero implements Serializable {
  private String heroName;
  private String realName;
  private String address;
  private String country;
  private String powerLevel;
  private String team;
  private String affiliation;
  private String weapon;
  private String origin;

  public Hero(String heroName, String realName, String address, String country, String powerLevel, String team, String affiliation, String weapon, String origin) {
    this.heroName = heroName;
    this.realName = realName;
    this.address = address;
    this.country = country;
    this.powerLevel = powerLevel;
    this.team = team;
    this.affiliation = affiliation;
    this.weapon = weapon;
    this.origin = origin;
  }

  public String getHeroName() {
    return heroName;
  }

  public void setHeroName(String heroName) {
    this.heroName = heroName;
  }

  public String getRealName() {
    return realName;
  }

  public void setRealName(String realName) {
    this.realName = realName;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public String getPowerLevel() {
    return powerLevel;
  }

  public void setPowerLevel(String powerLevel) {
    this.powerLevel = powerLevel;
  }

  public String getTeam() {
    return team;
  }

  public void setTeam(String team) {
    this.team = team;
  }

  public String getAffiliation() {
    return affiliation;
  }

  public void setAffiliation(String affiliation) {
    this.affiliation = affiliation;
  }

  public String getWeapon() {
    return weapon;
  }

  public void setWeapon(String weapon) {
    this.weapon = weapon;
  }

  public String getOrigin() {
    return origin;
  }

  public void setOrigin(String origin) {
    this.origin = origin;
  }
}
