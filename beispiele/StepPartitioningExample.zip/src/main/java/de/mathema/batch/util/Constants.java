package de.mathema.batch.util;

public class Constants {
    public static final String AVENGERS = "Avengers";
}
