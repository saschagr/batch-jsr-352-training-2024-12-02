package de.mathema.batch.job.myChunkStep.partition;

import java.io.IOException;
import java.util.Properties;

import jakarta.batch.api.partition.PartitionMapper;
import jakarta.batch.api.partition.PartitionPlan;
import jakarta.batch.api.partition.PartitionPlanImpl;

public class MyPartitionMapper implements PartitionMapper {
	@Override
	public PartitionPlan mapPartitions() throws Exception {
		System.out.println("PartitionMapper.mapPartitions()");
		PartitionPlan partitionPlan = new PartitionPlanImpl();
		partitionPlan.setPartitions(2);
		
		partitionPlan.setPartitionProperties(
				getProperties(partitionPlan.getPartitions()));

		return partitionPlan;
	}
	
	private Properties[] getProperties(int partitions) throws IOException {
		Properties[] propertiesArray = new Properties[partitions];
		System.out.println("Partitions = " + partitions);
		int anzahlDatensaetze = 200;
		int partitionSize = anzahlDatensaetze / partitions;
		for (int i = 0; i < partitions; i++) {
			Properties partitionProperties = new Properties();
			partitionProperties.put("partitionNumber", i);
			partitionProperties.put("firstItem", "" + i * 100);
			partitionProperties.put("lastItem",  "" + (i * 100 + 99));
			propertiesArray[i] = partitionProperties;
		}
		return propertiesArray;
    }

}
