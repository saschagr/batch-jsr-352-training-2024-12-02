package de.mathema.batch.job.definePowerLevel10Heroes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import de.mathema.batch.job.Hero;
import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.chunk.AbstractItemWriter;

public class  DBDefineEliteHeroWriter extends AbstractItemWriter {

  @Override
  public void writeItems(List<Object> items) throws Exception {

    DatabaseConfig config = DatabaseConnectionService.getConnectionConfig();

    try (Connection conn = DriverManager.getConnection(config.getJdbcUrl(), config.getUsername(), config.getPassword())) {
      String updateQuery = "UPDATE people SET " + "heroName = ?, " + "realName = ?, " + "address = ?, " + "country = ?, " + "powerLevel = ?, " + "team = ?, " + "affiliation = ?, " + "weapon = ?, " + "origin = ?," + "isEliteHero = ?" + "WHERE realName = ?";
      PreparedStatement preparedStatement = conn.prepareStatement(updateQuery);

      for (Object item : items) {
        Hero data = (Hero) item;
        preparedStatement.setString(1, data.getHeroName());
        preparedStatement.setString(2, data.getRealName());
        preparedStatement.setString(3, data.getAddress());
        preparedStatement.setString(4, data.getCountry());
        preparedStatement.setString(5, data.getPowerLevel());
        preparedStatement.setString(6, data.getTeam());
        preparedStatement.setString(7, data.getAffiliation());
        preparedStatement.setString(8, data.getTeam());
        preparedStatement.setString(9, data.getOrigin());
        preparedStatement.setBoolean(10, data.isEliteHero());
        preparedStatement.setString(11, data.getRealName());

        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      conn.commit();
    }
  }
}
