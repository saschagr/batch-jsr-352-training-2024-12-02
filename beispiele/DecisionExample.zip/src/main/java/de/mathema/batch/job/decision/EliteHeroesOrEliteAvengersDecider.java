package de.mathema.batch.job.decision;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.Decider;
import jakarta.batch.runtime.StepExecution;

public class EliteHeroesOrEliteAvengersDecider implements Decider {
    public final static String AVENGER_TEAM_NAME = "Avengers";
    public final static String ANOTHER_TEAM_NAME = "NotAvengers";
    private ResultSet resultSet;

    @Override
    public String decide(StepExecution[] executions) throws Exception {
        DatabaseConfig dbConfig = DatabaseConnectionService.getConnectionConfig();

        Connection connection = DriverManager.getConnection(dbConfig.getJdbcUrl(), dbConfig.getUsername(), dbConfig.getPassword());
        Statement statement = connection.createStatement();

        try {
            resultSet = statement.executeQuery("SELECT team  FROM people");

            boolean hasEliteAvengers = false;
            while (resultSet.next()) {
                String teamCurrentHero = resultSet.getString("team");
                if (AVENGER_TEAM_NAME.equalsIgnoreCase(teamCurrentHero)) {
                    hasEliteAvengers = true;
                    break;
                }
                System.out.println("Looking for elite avengers...");
            }
            if (hasEliteAvengers) {
                System.out.println("Elite avengers are found.");
            } else {
                System.out.println("Elite avengers are not found.");
            }

            return hasEliteAvengers ? "ELITE_AVENGERS_ASSEMBLE" : "SELECT_ELITE_HEROES";

        } finally {
            resultSet.close();
            statement.close();
            connection.close();
        }
    }
}












