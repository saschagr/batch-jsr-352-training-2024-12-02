package de.mathema.batch.job.anonymizeFlow;

import de.mathema.batch.job.Customer;
import de.mathema.batch.util.Randomizer;
import jakarta.batch.api.chunk.ItemProcessor;

public class DBAnonymizeAddressItemProcessor implements ItemProcessor {
  Randomizer randomizer = new Randomizer();
  
  @Override
  public Object processItem(Object item) {
    Customer currentCustomer = (Customer) item;
    return randomizer.anonymizeAddress(currentCustomer);
  }

}
