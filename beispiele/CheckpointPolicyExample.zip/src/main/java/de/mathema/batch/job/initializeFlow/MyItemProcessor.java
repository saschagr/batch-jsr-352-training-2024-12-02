package de.mathema.batch.job.initializeFlow;

import jakarta.batch.api.chunk.ItemProcessor;

public class MyItemProcessor implements ItemProcessor {

  @Override
  public Object processItem(Object item) {
	  System.out.println("processItem " + item);
    return item;
  }
}
