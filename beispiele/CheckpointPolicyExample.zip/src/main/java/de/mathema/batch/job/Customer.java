package de.mathema.batch.job;

public class Customer {

  private final String customerId;

  private String firstName;

  private String lastName;

  private String email;

  private final String phoneNumber;

  private String address;

  private final String city;

  private final String nationState;

  private final String zipCode;
  private final String entryDate;
  private final String revenue;
  private String membership;
  private String discountPercentage;

  public Customer(String customerId, String firstName, String lastName, String email, String phoneNumber, String address, String city, String nationState, String zipCode,
    String entryDate, String revenue) {
    this.customerId = customerId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.address = address;
    this.city = city;
    this.nationState = nationState;
    this.zipCode = zipCode;
    this.entryDate = entryDate;
    this.revenue = revenue;
  }

  public Customer(String customerId, String firstName, String lastName, String email, String phoneNumber, String address, String city, String nationState, String zipCode,
    String entryDate, String revenue, String membership, String discountPercentage) {
    this.customerId = customerId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.address = address;
    this.city = city;
    this.nationState = nationState;
    this.zipCode = zipCode;
    this.entryDate = entryDate;
    this.revenue = revenue;
    this.membership = membership;
    this.discountPercentage = discountPercentage;
  }

  public String getDiscountPercentage() {
    return discountPercentage;
  }

  public void setDiscountPercentage(String discountPercentage) {
    this.discountPercentage = discountPercentage;
  }

  public String getMembership() {
    return membership;
  }

  public void setMembership(String membership) {
    this.membership = membership;
  }

  public String getCustomerId() {
    return customerId;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public String getCity() {
    return city;
  }

  public String getNationState() {
    return nationState;
  }

  public String getZipCode() {
    return zipCode;
  }

  public String getEntryDate() {
    return entryDate;
  }

  public String getRevenue() {
    return revenue;
  }

  @Override
  public String toString() {
    return "Customer{" +
      "customerId='" + customerId + '\'' +
      ", firstName='" + firstName + '\'' +
      ", lastName='" + lastName + '\'' +
      ", email='" + email + '\'' +
      ", phoneNumber='" + phoneNumber + '\'' +
      ", address='" + address + '\'' +
      ", city='" + city + '\'' +
      ", nationState='" + nationState + '\'' +
      ", zipCode='" + zipCode + '\'' +
      ", entryDate='" + entryDate + '\'' +
      ", revenue='" + revenue + '\'' +
      ", membership='" + membership + '\'' +
      ", discountPercentage='" + discountPercentage + '\'' +
      '}';
  }
}