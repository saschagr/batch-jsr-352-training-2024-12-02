package de.mathema.batch.job.initializeFlow;

import jakarta.batch.api.chunk.CheckpointAlgorithm;
import jakarta.batch.runtime.context.StepContext;
import jakarta.inject.Inject;

public class MyCheckpointAlgorithm implements CheckpointAlgorithm {
  private static final int CHECKPOINT_INTERVAL = 25;
  @Inject
  private StepContext stepContext;
  private int itemCounter = 0;

  @Override
  public int checkpointTimeout() {
    return 5000;
  }

  @Override
  public void beginCheckpoint() {
    System.out.println("Begin checkpoint!");
  }

  @Override
  public boolean isReadyToCheckpoint() {
	System.out.println("isReadyToCheckpoint itemCounter = " + itemCounter);

    itemCounter++;
    stepContext.setTransientUserData(itemCounter);

    return itemCounter % CHECKPOINT_INTERVAL == 0;
  }

  @Override
  public void endCheckpoint() {
    System.out.println("End checkpoint");
  }
}
