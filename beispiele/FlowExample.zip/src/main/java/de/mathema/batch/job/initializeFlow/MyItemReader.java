package de.mathema.batch.job.initializeFlow;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import de.mathema.batch.job.Hero;
import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.chunk.AbstractItemReader;

public class MyItemReader extends AbstractItemReader {
  private BufferedReader reader;
  public final static int HERO_DATABASE_COLUMN_COUNT = 9;
  @Override
  public void open(Serializable checkpoint) throws Exception {
    DatabaseConfig config = DatabaseConnectionService.getConnectionConfig();

    try (Connection conn = DriverManager.getConnection(config.getJdbcUrl(), config.getUsername(), config.getPassword())) {
      try (Statement statement = conn.createStatement()) {
        statement.execute(
            "CREATE TABLE IF NOT EXISTS people (heroName varchar(255),realName varchar(255), address varchar(255), country varchar(255), powerLevel varchar(255), team varchar(255), affiliation varchar(255), weapon varchar(255), origin varchar(255)) ");
        statement.execute("DELETE FROM people");
      }
      InputStream inputStream = this.getClass().getResourceAsStream("/heroes.csv");
      reader = new BufferedReader(new InputStreamReader(inputStream));
    }
  }

  @Override
  public Object readItem() throws Exception {
    String line = reader.readLine();
    while (line != null) {
      String[] data = line.split(",");
      if (data.length != HERO_DATABASE_COLUMN_COUNT) {
        continue;
      }
      return new Hero(data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8]);
    }
    return null;
  }

  @Override
  public void close() throws Exception {
    if (reader != null) {
      reader.close();
    }
  }
}
