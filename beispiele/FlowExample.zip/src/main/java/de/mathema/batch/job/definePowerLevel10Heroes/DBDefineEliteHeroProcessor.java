package de.mathema.batch.job.definePowerLevel10Heroes;

import de.mathema.batch.job.Hero;
import jakarta.batch.api.chunk.ItemProcessor;

public class DBDefineEliteHeroProcessor implements ItemProcessor {
    @Override
    public Object processItem(Object item) {
        Hero currentHero = (Hero) item;

        int currentHeroPowerLevel = Integer.valueOf(currentHero.getPowerLevel());
        if (currentHeroPowerLevel >= 8) {
            currentHero.setEliteHero(true);
        } else {
            currentHero.setEliteHero(false);
        }

        return currentHero;
    }
}
