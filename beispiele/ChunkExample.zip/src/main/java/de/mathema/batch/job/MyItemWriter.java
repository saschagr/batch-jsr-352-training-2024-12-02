package de.mathema.batch.job;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.chunk.AbstractItemWriter;

public class MyItemWriter extends AbstractItemWriter {

  @Override
  public void writeItems(List<Object> items) throws Exception {
	  System.out.println("writeItems count = " + items.size());

    DatabaseConfig config = DatabaseConnectionService.getConnectionConfig();

    try (Connection conn = DriverManager.getConnection(config.getJdbcUrl(), config.getUsername(), config.getPassword())) {
      String insertQuery = """
      		INSERT INTO people 
      			(heroName, realName, address, country, powerlevel, team, affiliation, weapon, origin) 
      			VALUES (?,?,?,?,?,?,?,?,?)
      		""";
      PreparedStatement preparedStatement = conn.prepareStatement(insertQuery);

      for (Object item : items) {
        Hero data = (Hero) item;
        preparedStatement.setString(1, data.getHeroName());
        preparedStatement.setString(2, data.getRealName());
        preparedStatement.setString(3, data.getAddress());
        preparedStatement.setString(4, data.getCountry());
        preparedStatement.setString(5, data.getPowerLevel());
        preparedStatement.setString(6, data.getTeam());
        preparedStatement.setString(7, data.getAffiliation());
        preparedStatement.setString(8, data.getTeam());
        preparedStatement.setString(9, data.getOrigin());
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      conn.commit();
    }
  }
}
