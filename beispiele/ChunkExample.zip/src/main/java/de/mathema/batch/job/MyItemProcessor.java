package de.mathema.batch.job;

import jakarta.batch.api.chunk.ItemProcessor;

public class MyItemProcessor implements ItemProcessor {

  @Override
  public Object processItem(Object item) throws Exception {
    return item;
  }
}
