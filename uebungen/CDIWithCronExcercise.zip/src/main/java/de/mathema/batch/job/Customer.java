package de.mathema.batch.job;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Customer {

  @GeneratedValue
  @Id
  private Long customerId;

  private String firstName;

  private String lastName;

  private String email;

  private String phoneNumber;

  private String address;

  private String city;

  private String nationState;

  private String zipCode;

  public Customer(String firstName, String lastName, String email, String phoneNumber, String address, String city, String nationState, String zipCode) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.address = address;
    this.city = city;
    this.nationState = nationState;
    this.zipCode = zipCode;
  }
  public Customer() {
  }
}
