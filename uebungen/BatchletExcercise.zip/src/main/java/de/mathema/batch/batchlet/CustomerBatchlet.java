package de.mathema.batch.batchlet;

import jakarta.batch.api.AbstractBatchlet;

public class CustomerBatchlet extends AbstractBatchlet {

  @Override
  public String process() throws Exception {
    return null;
  }
}
