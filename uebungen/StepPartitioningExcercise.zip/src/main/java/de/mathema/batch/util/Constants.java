package de.mathema.batch.util;

public class Constants {
    public static final String MÜNCHEN = "München";

    public static final String SCHWARZ = "Schwarz";
}
