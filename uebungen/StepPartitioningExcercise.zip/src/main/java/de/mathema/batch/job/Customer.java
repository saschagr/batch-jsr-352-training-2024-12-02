package de.mathema.batch.job;

import java.io.Serializable;

public class Customer implements Serializable {

  private String customerId;

  private String firstName;

  private String lastName;

  private String email;

  private String phoneNumber;

  private String address;

  private String city;

  private String nationState;

  private String zipCode;

  public Customer(String customerId, String firstName, String lastName, String email, String phoneNumber, String address, String city, String nationState, String zipCode) {
    this.customerId = customerId;
    this.firstName = firstName;
    this.lastName = lastName;
    this.email = email;
    this.phoneNumber = phoneNumber;
    this.address = address;
    this.city = city;
    this.nationState = nationState;
    this.zipCode = zipCode;
  }

  public String getCustomerId() {
    return customerId;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getEmail() {
    return email;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public String getAddress() {
    return address;
  }

  public String getCity() {
    return city;
  }

  public String getNationState() {
    return nationState;
  }

  public String getZipCode() {
    return zipCode;
  }

  public void setZipCode(String zipCode) {
    this.zipCode = zipCode;
  }

  @Override
  public String toString() {
    return "Customer{" +
            "customerId='" + customerId + '\'' +
            ", firstName='" + firstName + '\'' +
            ", lastName='" + lastName + '\'' +
            ", email='" + email + '\'' +
            ", phoneNumber='" + phoneNumber + '\'' +
            ", address='" + address + '\'' +
            ", city='" + city + '\'' +
            ", nationState='" + nationState + '\'' +
            ", zipCode='" + zipCode + '\'' +
            '}';
  }
}
