package de.mathema.batch.job.myChunkStep.partition;

public class MyPartitionReducer {

}

