package de.mathema.batch.job.defineMembershipFlow;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.List;

import de.mathema.batch.job.Customer;
import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.chunk.AbstractItemWriter;

public class DefineMembershipWriter extends AbstractItemWriter {

  @Override
  public void writeItems(List<Object> items) throws Exception {

    DatabaseConfig dbConfig = DatabaseConnectionService.getConnectionConfig();

    try (Connection conn = DriverManager.getConnection(dbConfig.getJdbcUrl(), dbConfig.getUsername(), dbConfig.getPassword())) {
      String updateQuery = "UPDATE customers SET " +
        "customerId = ?, " +
        "firstName = ?, " +
        "lastName = ?, " +
        "email = ?, " +
        "phoneNumber = ?, " +
        "address = ?, " +
        "city = ?, " +
        "nationState = ?, " +
        "zipCode = ?," +
        "entryDate = ?, " +
        "revenue = ? " +
        "WHERE customerId = ?";
      PreparedStatement preparedStatement = conn.prepareStatement(updateQuery);

      for (Object item : items) {
        Customer data = (Customer) item;
        preparedStatement.setString(1, data.getCustomerId());
        preparedStatement.setString(2, data.getFirstName());
        preparedStatement.setString(3, data.getLastName());
        preparedStatement.setString(4, data.getEmail());
        preparedStatement.setString(5, data.getPhoneNumber());
        preparedStatement.setString(6, data.getAddress());
        preparedStatement.setString(7, data.getCity());
        preparedStatement.setString(8, data.getNationState());
        preparedStatement.setString(9, data.getZipCode());
        preparedStatement.setString(10, data.getEntryDate());
        preparedStatement.setString(11, data.getRevenue());
        preparedStatement.setString(12, data.getCustomerId());
        preparedStatement.addBatch();
      }
      preparedStatement.executeBatch();
      conn.commit();
    }
  }

}
