package de.mathema.batch.job.initializeFlow;

import jakarta.batch.api.chunk.ItemProcessor;

public class MyItemProcessor implements ItemProcessor {

  @Override
  public Object processItem(Object item) {
    return item;
  }
}
