package de.mathema.batch.job;

import jakarta.batch.api.chunk.ItemProcessor;

public class CustomerItemProcessor implements ItemProcessor {

  @Override
  public Object processItem(Object item) throws Exception {
    return item;
  }
}
