package de.mathema.batch.job.calculateDiscountPercentageFlow;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import de.mathema.batch.job.Customer;
import de.mathema.batch.util.DatabaseConfig;
import de.mathema.batch.util.DatabaseConnectionService;
import jakarta.batch.api.BatchProperty;
import jakarta.batch.api.chunk.AbstractItemReader;

public class DBItemReaderAllColumns extends AbstractItemReader {
  private ResultSet resultSet;
  private Connection connection;
  private Statement statement;
  
  @BatchProperty
  private String city;

  @Override
  public void open(Serializable checkpoint) throws Exception {

    DatabaseConfig config = DatabaseConnectionService.getConnectionConfig();
    connection = DriverManager.getConnection(config.getJdbcUrl(), config.getUsername(), config.getPassword());

    statement = connection.createStatement();
    if (city == null) {
    	resultSet = statement.executeQuery("SELECT * FROM customers");
    } else {
    	resultSet = statement.executeQuery("SELECT * FROM customers WHERE city like '" +  city + "'");
    }
  }

  @Override
  public Object readItem() throws Exception {

    if (resultSet.next()) {
      return new Customer(
        resultSet.getString("customerId"),
        resultSet.getString("firstName"),
        resultSet.getString("lastName"),
        resultSet.getString("email"),
        resultSet.getString("phoneNumber"),
        resultSet.getString("address"),
        resultSet.getString("city"),
        resultSet.getString("nationState"),
        resultSet.getString("zipCode"),
        resultSet.getString("entryDate"),
        resultSet.getString("revenue"),
        resultSet.getString("membership"),
        resultSet.getString("discountPercentage")
      );
    }
    return null;
  }

  @Override
  public void close() throws Exception {
    resultSet.close();
    statement.close();
    connection.close();
  }
}
