package de.mathema.batch.util;


import java.util.Random;

import de.mathema.batch.job.Customer;

public class Randomizer {

  Random random = new Random();
  public Customer anonymizeEmail(Customer customer) {
    // Generate random first name and last name
    String randomEmail = generateRandomName(8) + "@" + generateRandomName(8) + ".de"; // You can specify the desired length
    customer.setEmail(randomEmail);
    return customer;
  }
  public Customer anonymizeAddress(Customer customer) {
    // Generate random first name and last name
    String randomAddress = generateRandomName(8) + "straße " + (random.nextInt(90) + 10); // You can specify the desired length
    customer.setAddress(randomAddress);
    return customer;
  }
  public Customer anonymizeName(Customer customer) {
    // Generate random first name and last name
    String randomFirstName = generateRandomName(8); // You can specify the desired length
    String randomLastName = generateRandomName(10); // You can specify the desired length

    customer.setFirstName(randomFirstName);
    customer.setLastName(randomLastName);
    return customer;
  }
  private String generateRandomName(int length) {
    String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    StringBuilder randomName = new StringBuilder();
    Random random = new Random();

    for (int i = 0; i < length; i++) {
      int index = random.nextInt(characters.length());
      char randomChar = characters.charAt(index);
      randomName.append(randomChar);
    }

    return randomName.toString();
  }
}
